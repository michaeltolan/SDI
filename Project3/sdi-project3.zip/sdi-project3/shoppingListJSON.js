var shoppingListJSON = {
	"walmart": {
		"groceries": [],
		"tech": [],
		"auto": []
	},
	"target": {
		"apparel": [],
		"toys": [],
		"baby": []
	},
	"sams": {
		"outdoor": [],
		"home": [],
		"hygiene": []
	}
};
